const BGN_TO_EUR_RATE = 1.95583;

export function ConvertToEuro(target: object, propertyKey: string, descriptor: PropertyDescriptor) {
	if (!descriptor.get) {
		throw new Error('ConvertToEuro can only be applied to getters');
	}

	const originalGetter = descriptor.get;

	descriptor.get = function (this: any) {
		const priceBGN = originalGetter.call(this);

		if (priceBGN === undefined) {
			return undefined;
		}

		const priceEUR = priceBGN / BGN_TO_EUR_RATE;

		return Math.round(priceEUR * 100) / 100;
	};
}
