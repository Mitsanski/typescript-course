import { ConvertToEuro } from './decorators';
import { MenuItem, MenuItemType } from './models';

export abstract class BaseMenuItem implements MenuItem {
	id: number;
	name: string;
	weightGrams: number;
	type: MenuItemType;
	protected _basePrice: number | undefined;
	constructor(
		id: number,
		name: string,
		weightGrams: number,
		type: MenuItemType,
		basePrice?: number
	) {
		this.id = id;
		this.name = name;
		this.weightGrams = weightGrams;
		this.type = type;
		this._basePrice = basePrice || undefined;
	}

	abstract getCalories(): number;

	get basePrice(): number | undefined {
		return this._basePrice;
	}

	@ConvertToEuro
	get finalPrice(): number | undefined {
		return this._basePrice;
	}
}

export class WelcomeSnack extends BaseMenuItem {
	public hasCream: boolean;

	constructor(id: number, name: string, weightGrams: number, hasCream: boolean) {
		super(id, name, weightGrams, MenuItemType.WelcomeSnack);
		this.hasCream = hasCream;
	}

	public getCalories(): number {
		return this.weightGrams * 1.2 + (this.hasCream ? 20 : 0);
	}
}

export class MainCourse extends BaseMenuItem {
	public fatGrams: number;

	constructor(
		id: number,
		name: string,
		weightGrams: number,
		fatGrams: number,
		basePrice?: number
	) {
		super(id, name, weightGrams, MenuItemType.MainCourse, basePrice);
		this.fatGrams = fatGrams;
	}

	public getCalories(): number {
		return this.weightGrams * 2.0 + this.fatGrams * 3;
	}
}

export class Dessert extends BaseMenuItem {
	public hasSugar: boolean;

	constructor(
		id: number,
		name: string,
		weightGrams: number,
		hasSugar: boolean,
		basePrice?: number
	) {
		super(id, name, weightGrams, MenuItemType.Dessert, basePrice);
		this.hasSugar = hasSugar;
	}

	public getCalories(): number {
		return this.weightGrams * 2.5 + (this.hasSugar ? 100 : 0);
	}
}
