enum MenuItemType {
	WelcomeSnack = 'WelcomeSnack',
	MainCourse = 'MainCourse',
	Dessert = 'Dessert',
}

interface MenuItem {
	id: number;
	name: string;
	weightGrams: number;
	type: MenuItemType;
}

interface Client {
	name: string;
	phone: string;
}

interface WithId {
	id: number;
}

export { Client, MenuItem, MenuItemType, WithId };
