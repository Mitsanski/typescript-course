import { BaseMenuItem } from './menu-item-types';
import { Client, WithId } from './models';

export function findItemById<T extends WithId>(items: T[], id: number): T | undefined {
	return items.find((item) => item.id === id);
}

export class MenuManager {
	private menuItems: BaseMenuItem[] = [];
	private clients: Map<number, Client[]> = new Map();

	addMenuItem(item: BaseMenuItem): string {
		this.menuItems.push(item);

		this.clients.set(item.id, []);

		return `Menu item "${item.name}" (ID: ${item.id}) has been added.`;
	}

	registerClient(itemId: number, client: Client): string {
		const item = this.menuItems.find((i) => i.id === itemId);

		if (!item) {
			return `ERROR: Menu item with ID ${itemId} not found.`;
		}

		this.clients.get(itemId)!.push(client);

		return `Client ${client.name} registered for menu item ID ${itemId} successfully.`;
	}

	listAllItems(): string[] {
		let output: string[] = [];

		output.push('--- List of All Menu Items ---');
		for (let item of this.menuItems) {
			const type = item.type.toUpperCase();
			const calories = item.getCalories().toFixed(2);
			output.push(`[${type}] ${item.name} (${item.weightGrams}g) - Calories: ${calories}`);
		}
		return output;
	}

	public findMenuItem(itemId: number): BaseMenuItem | undefined {
		return findItemById(this.menuItems, itemId);
	}
}
